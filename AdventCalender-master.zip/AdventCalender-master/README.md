<p align="center"> 
<img src="https://github.com/yourappsgeek/AdventCalender/blob/master/screenshots/advent-tree.png" width="200" height="200">
<br>
<strong>Advent Calender App</strong>
</p>

## Description

- The advent calendar consists of 24 "doors" which can be opened by tapping.

- User search the calendar with the eyes to find the current day.

- For each day of the month, only the doors up until the current day can be opened. For example, if today was Jan the 4th, only the days "1", "2", "3" and "4" can be opened. All other doors will stay closed.
